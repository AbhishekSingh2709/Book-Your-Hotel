package com.bookyourhotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookYourHotelApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookYourHotelApplication.class, args);
	}

}
