package com.bookyourhotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookYourHotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
